export interface IDrawable {
    draw(deltaTime: number): void;
}
