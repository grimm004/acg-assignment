export interface IUpdatable {
    update(deltaTime: number): void;
}
