import {App} from "./app/app";

class Program {
    public static main(): number {
        new App().run();
        return 0;
    }
}

Program.main();
